//
//  list.h
//  virt_mem
//
//  Created by William McCarthy on 4/18/19.
//  Copyright © 2019 William McCarthy. All rights reserved.
//

#ifndef list_h
#define list_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define BUFLEN 256


//----------------------------------------------------------------------------------
// listnode
//----------------------------------------------------------------------------------
typedef struct listnode listnode;
struct listnode {
  int value;
  listnode* prev;
  listnode* next;
};

listnode* listnode_make(int value, listnode* prev, listnode* next);
const char* listnode_tostring(listnode* no);


//----------------------------------------------------------------------------------
// list
//----------------------------------------------------------------------------------
typedef struct list list;
struct list {
  listnode* head;
  listnode* tail;
  size_t size;
};

//----------------------------------------------------------------------------------
list* list_make(void);
void list_delete(list* li);

listnode* list_front(list* li);
listnode* list_back(list* li);
int       list_empty(list* li);
size_t    list_size(list* li);

void      list_movefront(list* li, int value);
listnode* list_clipfront(list* li);
listnode* list_clipback(list* li);
void      list_popfront(list* li);
void      list_popback(list* li);
void      list_pushfront(list* li, listnode* no);
void      list_pushback(list* li, listnode* no);

void list_rotateright(list* li);
void list_rotateleft( list* li);
void list_rotate(list* li, int n);

void list_print(list* li);

void test_list(void);

#endif /* list_h */
