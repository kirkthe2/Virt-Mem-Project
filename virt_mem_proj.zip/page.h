//
//  page.h
//  virt_mem
//
//  Created by William McCarthy on 4/18/19.
//  Copyright © 2019 William McCarthy. All rights reserved.
//

#ifndef pagetable_h
#define pagetable_h

#include <stdio.h>
#include <stdlib.h>
#include "list.h"
//#include "tlb.h"

#define OVERFLOW_ERROR  10
#define MEMORY_ERROR 11
#define READ_ERROR 12
#define REPLACEMENTMODE_ERROR 13


typedef enum PAGE_REPLACEMODE PAGE_REPLACEMODE;
enum PAGE_REPLACEMODE { SIMPLE, FIFO, LRU };


typedef struct tlb_entry tlb_entry;
struct tlb_entry {
  int page;
  int frame;
};

typedef struct tlbtable tlbtable;
struct tlbtable {
  unsigned int size;
  unsigned int hits;
  unsigned int misses;
  unsigned int tlbnextavail;
  tlb_entry* table;
};


typedef struct pagetable pagetable;
struct pagetable {
  int* table;
  char* phys_mem;
  list* page_lru;
  FILE* fbacking;

  unsigned int counter;
  unsigned int nextavailable;

  unsigned int faults;
  unsigned int pages;
  unsigned int pagesize;
  unsigned int frames;
  unsigned int framesize;
  
  PAGE_REPLACEMODE replacemode;
};


tlbtable* tlb_make(unsigned int entries);
void tlb_delete(tlbtable* tlb);

int tlb_getframe(tlbtable* tlb, pagetable* pt, unsigned int page);
void tlb_update(tlbtable* tlb, int page, int frame);
void tlb_printhitrate(tlbtable* tlb, pagetable* pt);



unsigned int getpage(size_t x);//
unsigned int getoffset(unsigned int x);//

pagetable* pagetable_make(unsigned int pages, unsigned int pagesize, unsigned int frames, unsigned int framesize,
                          FILE* fbacking, PAGE_REPLACEMODE replacemode);
void pagetable_delete(pagetable* pt);

int pagetable_getframe(pagetable* pt, tlbtable* tlb, unsigned int page);
int pagetable_pagefault(pagetable* pt, tlbtable* tlb, unsigned int page);
int pagetable_next(pagetable* pt, tlbtable* tlb);
void pagetable_update(pagetable* pt, int page, int frame);

void pagetable_printfaultrate(pagetable* pt);


#endif /* pagetable_h */
