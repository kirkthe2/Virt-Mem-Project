//
//  virt_mem.c
//  virt_mem
//
//  Created by William McCarthy on 3/23/19.
//  Copyright © 2019 William McCarthy. All rights reserved.
//

#include "page.h"

#define ARGC_ERROR 1
#define FILE_ERROR 2
#define READ_ERROR 3
#define BUFLEN 256
#define FRAME_SIZE  256

tlbtable TLB;
pagetable pageTab;
  
//-------------------------------------------------------------------
unsigned int getpage(size_t x) { return (0xff00 & x) >> 8; }
unsigned int getoffset(unsigned int x) { return (0xff & x); }

void getpage_offset(unsigned int x) {
  unsigned int page = getpage(x);
  unsigned int offset = getoffset(x);
  printf("x is: %u, page: %u, offset: %u, address: %u, paddress: %u\n", x, page, offset,
         (page << 8) | getoffset(x), page * 256 + offset);
}

tlbtable* tlbmake(unsigned int entries)
{
	tlbtable* tlb = (tlbtable*)malloc(sizeof(tlbtable));
	
	return tlb;
}
pagetable* pagetable_make(unsigned int pages, unsigned int pagesize, unsigned int frames, unsigned int framesize,
                          FILE* fbacking, PAGE_REPLACEMODE replacemode)
{
	pagetable* pTab = (pagetable*)malloc(sizeof(pagetable));
	
	return pTab;
}

void tlb_delete(tlbtable* tlb)
{

}

int tlb_getframe(tlbtable* tlb, pagetable* pt, unsigned int page)
{
	int frame = -1;
	if(tlb == NULL)
	{
		return frame;
	}
	if(pt != NULL)
	{
		
	}
	return frame;
}

void tlb_update(tlbtable* tlb,int page, int frame)
{
	
}

void tlb_printhitrate(tlbtable* tlb, pagetable* pt)
{

}

void pagetable_delete(pagetable* pt)
{

}

int pagetable_pagefault(pagetable* pt, tlbtable* tlb, unsigned int page)
{

}

int pagetable_next(pagetable* pt, tlbtable* tlb)
{

}

void pagetable_update(pagetable* pt, int page, int frame)
{
	
}

int pagetable_getframe(pagetable* pt, tlbtable* tlb, unsigned int page)
{
        
}

void pagetable_printfaultrate(pagetable* pt)
{

}

int main(int argc, const char * argv[]) {
  FILE* fadd = fopen("addresses.txt", "r");
  if (fadd == NULL) { fprintf(stderr, "Could not open file: 'addresses.txt'\n");  exit(FILE_ERROR);  }
  FILE* fcorr = fopen("correct.txt", "r");
  if (fcorr == NULL) { fprintf(stderr, "Could not open file: 'correct.txt'\n");  exit(FILE_ERROR);  }
  FILE *fptr = fopen("BACKING_STORE.bin", "rb");  
  if (fptr == NULL) { fprintf(stderr, "Could not open file: 'BACKING_STORE.bin'\n");  exit(FILE_ERROR);  }
  char buf[BUFLEN];
  char* phys_mem = (char*) malloc(FRAME_SIZE * sizeof(char));
  unsigned int page, offset, physical_add, frame = 0;
  unsigned int logic_add;                  // read from file address.txt
  unsigned int virt_add, phys_add, corr_value;  // read from file correct.txt
  
  unsigned int value;
  int tlbHits = 0;
  int pageFaults = 0;
  int addressesProcessed = 0;
      // not quite correct -- should search page table before creating a new entry
      //   e.g., address # 25 from addresses.txt will fail the assertion
      // TODO:  add page table code
      // TODO:  add TLB code
	
  while (frame < 25) {
    addressesProcessed++;
    fscanf(fcorr, "%s %s %d %s %s %d %s %d", buf, buf, &virt_add,
           buf, buf, &phys_add, buf, &corr_value);  // read from file correct.txt

    fscanf(fadd, "%d", &logic_add);  // read from file address.txt
    page = getpage(logic_add);
    offset = getoffset(logic_add);
    /*frame = checkTLB(page);
    if(frame == -1)
    {*/
	//frame = checkTLB(page);
    /*}
    else
    {
	tlbHits++;
    }*/
    physical_add = frame++ * FRAME_SIZE + offset;
    value = *(phys_mem + physical_add);
    assert(physical_add == phys_add);
    assert(value == corr_value);
	
    // todo: read BINARY_STORE and confirm value matches read value from correct.txt
    printf("logical: %5u (page:%3u, offset:%3u) ---> physical: %5u -- passed\n", logic_add, page, offset, physical_add);
    if (frame % 5 == 0) { printf("\n"); }

  }
  fclose(fcorr);
  fclose(fadd);
  free(phys_mem);
  double faultRate = (double) pageFaults / addressesProcessed;
  double tlbHitRate = (double) tlbHits / addressesProcessed;
  printf("Page-fault Rate: %f, TLB hit rate: %f\n",faultRate, tlbHitRate);
  printf("ALL logical ---> physical assertions PASSED!\n");
  printf("!!! This doesn't work passed entry 24 in correct.txt, because of a duplicate page table entry\n");
  printf("--- you have to implement the PTE and TLB part of this code\n");
  printf("\n\t\t...done.\n");
  return 0;
}
