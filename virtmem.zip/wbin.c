//
//  main.c
//  wbin
//
//  Created by William McCarthy on 4/20/19.
//  Copyright © 2019 William McCarthy. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

#define FRAMES  16
#define FRAMESIZE 256
#define ARGC_ERROR  1
#define FILE_ERROR 2

int main(int argc, const char * argv[]) {
  if (argc != 3) { fprintf(stderr, "Usage: ./wbin nblocks(of256) filename\n");  exit(ARGC_ERROR); }
  
  FILE* fout;
  const char* outfile = argv[2];
  if ((fout = fopen(outfile, "wb")) == NULL) { fprintf(stderr, "Could not create: '%s'\n", outfile);  exit(FILE_ERROR); }
  
  unsigned int frames = atoi(argv[1]);
  for (int i = 0; i < frames; ++i) {
    fwrite(&i, sizeof(char), 1, fout);
    for (int x = 1; x != FRAMESIZE; ++x) {
      int y = (i + 1) * x;     // y = x (1st time), y = 2x (2nd time), 3x (3rd time)...
      fwrite(&y, sizeof(char), 1, fout); }
  }
  fclose(fout);
  return 0;
}
