//
//  list.c
//  virt_mem
//
//  Created by William McCarthy on 4/18/19.
//  Copyright © 2019 William McCarthy. All rights reserved.
//

#include "list.h"


//----------------------------------------------------------------------------------
listnode* listnode_make(int value, listnode* prev, listnode* next) {
  listnode* no = (listnode*) malloc(sizeof(listnode));
  if (no == NULL) { return no; }
  
  no->value = value;
  no->prev = prev;
  no->next = next;
  return no;
}
const char* listnode_tostring(listnode* no) {
  static char buf[BUFLEN];
  memset(buf, 0, sizeof(buf));
  if (no == NULL) { strcpy(buf, "null node");  return buf; }
  
  snprintf(buf, sizeof(buf), "%d ", no->value);
//  snprintf(buf, sizeof(buf), "%11p <-- %3d --> %11p\n", no->prev, no->value, no->next);
  return buf;
}


//----------------------------------------------------------------------------------
// list
//----------------------------------------------------------------------------------
list* list_make(void) {
  list* li = (list*) malloc(sizeof(list));
  if (li != NULL) {
    li->head = li->tail = NULL;
    li->size = 0;
  }
  return li;
}

int    list_empty(list* li)    { return li->size == 0; }
size_t list_size(list* li)     { return li->size; }

listnode* list_front(list* li) { return li->head; }
listnode* list_back(list* li)  { return li->tail; }

void list_pushfront(list* li, listnode* no) {
  no->prev = NULL;      // node modifications
  no->next = li->head;
  if (li->head != NULL) { li->head->prev = no; }
  
  if (li->size == 0) { li->tail = no; }    // list modifications
  li->head = no;
  li->size++;
}

void list_pushback(list* li, listnode* no) {
  if (list_empty(li)) { list_pushfront(li, no);  return; }
  no->prev = li->tail;   // node modifications
  no->next = NULL;
  
  li->tail->next = no;   // list modifications
  li->tail = no;
  li->size++;
}

void list_popfront(list* li) { free(list_clipfront(li)); }
void list_popback(list* li) {  free(list_clipback(li)); }

listnode* list_clipfront(list* li) {
  if (list_empty(li)) { fprintf(stderr, "trying to pop empty list\n");  return NULL; }
  
  listnode* p = li->head;  // save ptr to node being clipped
  if (list_size(li) == 1) { li->head = li->tail = NULL;
  } else {
    li->head = li->head->next;
    if (li->head != NULL) { li->head->prev = NULL; }
  }
  li->size--;
  return p;
}
listnode* list_clipback(list* li) {
  if (li->size <= 1) { return list_clipfront(li); }
  listnode* p = li->tail;  // save ptr to node being clipped
  listnode* prev = li->tail->prev;
  prev->next = NULL;
  li->tail = prev;
  
  li->size--;
  return p;
}


void list_movefront(list* li, int value) {
  if (li->size == 0) { list_pushfront(li, listnode_make(value, NULL, NULL));  return; }  // empty
  if (li->size == 1 || li->head->value == value) { return; }                             // already there
  if (li->tail->value == value) { list_rotateright(li);  return; }                       // at end
  
  listnode* p = li->head;
  while (p != NULL && p->value != value) { p = p->next; }
  if (p == NULL) { return; }

  listnode* prev = p->prev;
  listnode* next = p->next;
  prev->next = next;
  next->prev = prev;

  li->size--;
  list_pushfront(li, p);
}

void list_print(list* li) {
  if (list_empty(li)) { printf("list is empty\n");  return; }
  
  printf("list: ");
  listnode* p = list_front(li);
  while (p != NULL) {
    printf("%s", listnode_tostring(p));
    p = p->next;
  }
  printf("\n");
}

void list_delete(list* li) {
  listnode* p = list_front(li);
  while (p != NULL) {
    listnode* q = p;  // save ptr to node to free
    p = p->next;
    free(q);    // free listnode
  }
  free(li);    // free list
}

void list_rotateright(list* li) {
  if (list_size(li) <= 1) { return; }
  
  listnode* p = list_clipback(li);
  list_pushfront(li, p);
}

void list_rotateleft(list* li) {
  if (list_size(li) <= 1) { return; }
  
  listnode* p = list_clipfront(li);
  list_pushback(li, p);
}

void list_rotate(list* li, int n) {
  size_t size = list_size(li);
  if (size <= 1 || size % n == 0) { return; }
  
  int negative = n < 0;
  n *= negative ? -1 : 1;
  n %= size;    // optimize (e.g., rotate 401 times a list w/4 items == rotate once)
  
  while (n-- > 0) {
    if (negative) { list_rotateleft(li); }
    else {
      list_rotateright(li);
    }
  }
}


void test_list(void) {
  list* li = list_make();
  list_pushfront(li, listnode_make(10, NULL, NULL));  list_print(li);
  list_pushfront(li, listnode_make( 8, NULL, NULL));  list_print(li);
  list_pushfront(li, listnode_make( 6, NULL, NULL));  list_print(li);
  list_pushfront(li, listnode_make( 4, NULL, NULL));  list_print(li);
  list_pushfront(li, listnode_make( 2, NULL, NULL));  list_print(li);
  
  list_pushback(li, listnode_make(20, NULL, NULL));  list_print(li);
  list_pushback(li, listnode_make(18, NULL, NULL));  list_print(li);
  list_pushback(li, listnode_make(16, NULL, NULL));  list_print(li);
  list_pushback(li, listnode_make(14, NULL, NULL));  list_print(li);
  list_pushback(li, listnode_make(12, NULL, NULL));  list_print(li);
  
  list_print(li);
  
  list_movefront(li, 4);   list_print(li);
  list_movefront(li, 6);   list_print(li);
  list_movefront(li, 8);   list_print(li);
  list_movefront(li, 10);  list_print(li);
  
  printf("rotating left...\n");  list_rotateleft(li);   list_print(li);
  printf("rotating left...\n");  list_rotateleft(li);   list_print(li);
  printf("rotating left...\n");  list_rotateleft(li);   list_print(li);
  printf("rotating left...\n");  list_rotateleft(li);   list_print(li);
  printf("rotating left...\n");  list_rotateleft(li);   list_print(li);
  
  printf("rotating right...\n");  list_rotateright(li);   list_print(li);
  printf("rotating right...\n");  list_rotateright(li);   list_print(li);
  printf("rotating right...\n");  list_rotateright(li);   list_print(li);
  printf("rotating right...\n");  list_rotateright(li);   list_print(li);
  printf("rotating right...\n");  list_rotateright(li);   list_print(li);
  
  printf("deleting list one by one...\n");
  while (!list_empty(li)) {
    list_popfront(li);
    // list_popback(li);
    list_print(li);
  }
  
  list_delete(li);
}
